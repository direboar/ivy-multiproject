package common;

public class Com {

	public void exec(){
		System.out.println("x");
	}

}
