package x;

import com.Apps;

public class Hoge {

	public static void main(String args[]) throws Exception{
		Apps apps = new Apps();
		apps.hello();
	}
}
